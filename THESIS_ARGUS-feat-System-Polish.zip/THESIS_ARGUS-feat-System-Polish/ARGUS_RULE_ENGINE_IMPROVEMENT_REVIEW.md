# ARGUS-Lite Rule Engine: Cue Verification and Improvement Review

## Purpose and scope

This review examines whether the cues produced by the current ARGUS-Lite rule-based Multimodal Behavior Inference Engine (MBIE) match what the source code actually measures, whether they are suitable as behavioral-screening cues, and what should be improved before stronger claims are made.

The review covers:

- `face_head_orientation_extractor_segmented.py`
- `gaze_tracker.py`
- `posture_detector.py`
- `mbie_vector_fusion.py`
- the saved MBIE outputs for EXAM-P01 through EXAM-P11

The evaluation scripts and analysis notebook were also checked for consistency with the rule engine. The cues reviewed here are observable video-derived conditions. They are not direct indicators of cheating, probabilities of cheating, or proof of academic dishonesty.

## Overall conclusion

The current cue set is reasonable as an exploratory set of observable conditions for a proof-of-concept screening system. However, the cues are not equally reliable, and several names imply more than the calculations establish. The largest problem is `upper_torso_posture_shift`, which is mostly an absolute camera-framing measurement rather than a temporal posture change. Two configured cues, `sustained_offscreen_gaze` and `high_upper_torso_movement`, never activated in the saved dataset.

The rules and cue-strength contributions are manually defined. The current session-level labels cannot verify whether each cue correctly detects its intended behavioral event because there are no independent event-level annotations. Consequently, the system can be described as a rule-based behavioral-cue screening engine, but the individual rules and weights should be treated as provisional until they are validated.

## How the rule engine currently works

The three extractors sample recorded webcam video and produce timestamped JSON records. MBIE groups records into one-second windows, aggregates each modality, activates predefined cues, and adds fixed heuristic contributions to a per-second `cue_strength` value.

For Boolean extractor features, MBIE generally activates the aggregated feature when it is true in at least 50% of the usable samples within that second. At the default sampling target of 15 FPS, this normally means approximately eight samples, although the actual number depends on video FPS and feature availability.

The cue-strength value is clipped to the range 0.0 to 1.0. It is a heuristic index for selecting information-dense moments. It is not a learned probability, calibrated confidence score, risk probability, or final classification.

## Current active-cue inventory

| Active cue | Current trigger | Contribution | Assessment |
|---|---|---:|---|
| `sustained_offscreen_gaze` | Aggregated gaze is offscreen for at least five consecutive one-second windows | 0.20 | Retain provisionally, but rename and calibrate |
| `sustained_head_offscreen` | Aggregated head yaw is beyond the extractor threshold for at least five consecutive one-second windows | 0.15 | Retain provisionally, but rename |
| `sustained_face_absence` | Face is absent in most samples for at least five consecutive one-second windows | 0.20 | Retain as an observability/review cue |
| `simultaneous_gaze_and_head_offscreen` | Gaze and head deviation flags are both active in the same second | 0.08 | Retain as a combined pattern, with dependency caution |
| `offcenter_face_with_attention_shift` | Face-center distance is at least 0.35 and gaze or head deviation is active | 0.04 | Treat as context rather than independent evidence |
| `reduced_face_visibility_context` | Face area is at most 0.04 while a face is present and gaze or head deviation is active | 0.03 | Move to quality/context information |
| `hand_near_mouth` | Either wrist is within 0.20 normalized frame units of the mouth in at least half of visible-posture samples | 0.10 | Retain only after visibility and scale corrections |
| `elevated_hands` | At least one wrist is near or above shoulder height in at least half of visible-posture samples; suppressed when hand-near-mouth is active | 0.05 | Retain provisionally with visibility checks |
| `upper_torso_posture_shift` | Shoulder tilt is above 0.18, shoulder-center distance from frame center is above 0.22, or shoulder width is below 0.22 | 0.10 | Replace or rename; current implementation is misleading |
| `high_upper_torso_movement` | Shoulder-midpoint displacement between sampled frames is above 0.06 | 0.05 | Retain only after time normalization |
| `mouth_activity_with_hand_near_mouth` | Hand-near-mouth is active and any mouth-opening activity occurs in the same one-second window | Up to 0.08 | Retain as window-level co-occurrence with clearer wording |
| `multimodal_corroboration` | Active evidence is registered from at least two feature groups | 0.10 | Keep as metadata; reconsider adding a separate weight |

## Activation observed in the saved dataset

The saved MBIE outputs contain 8,868 one-second event records. Their active-cue counts are:

| Cue | Active windows | Percentage of all windows |
|---|---:|---:|
| `upper_torso_posture_shift` | 7,916 | 89.26% |
| `multimodal_corroboration` | 2,577 | 29.06% |
| `sustained_head_offscreen` | 2,232 | 25.17% |
| `hand_near_mouth` | 959 | 10.81% |
| `elevated_hands` | 464 | 5.23% |
| `offcenter_face_with_attention_shift` | 347 | 3.91% |
| `mouth_activity_with_hand_near_mouth` | 95 | 1.07% |
| `sustained_face_absence` | 95 | 1.07% |
| `reduced_face_visibility_context` | 52 | 0.59% |
| `simultaneous_gaze_and_head_offscreen` | 19 | 0.21% |
| `sustained_offscreen_gaze` | 0 | 0.00% |
| `high_upper_torso_movement` | 0 | 0.00% |

An activation rate does not establish correctness. It is a diagnostic indicator showing whether a rule is excessively common, inactive, or potentially dependent on camera setup.

## Cue-by-cue verification

### 1. Sustained gaze deviation

The underlying gaze value is a horizontal iris-position proxy computed relative to eye landmarks. It is not a calibrated point of regard, an exact object being viewed, or a verified departure from the examination screen. Therefore, `sustained_offscreen_gaze` would be more accurately named `sustained_horizontal_gaze_deviation`.

The temporal design is reasonable: MBIE first requires the condition in at least half of the usable samples in a one-second window and then requires five consecutive active windows. However, this cue never activated in the current saved outputs. This should be investigated to determine whether the gaze threshold is too strict, the horizontal proxy has insufficient range, or participants simply did not meet the rule.

**Recommendation:** retain the cue provisionally, calibrate it per camera setup or participant, assess gaze-landmark quality, and report the zero-activation finding.

### 2. Sustained head deviation

The rule is technically implemented as designed: the extractor flags frames where absolute estimated yaw exceeds 25 degrees, MBIE aggregates the frame flags, and the sustained cue activates after five consecutive one-second windows. The name `head_offscreen` is inaccurate because the rule measures head yaw and does not establish that the head or attention is outside the examination screen.

This cue activated in approximately one quarter of all event windows after reaching its persistence requirement. Because the head-pose estimate depends on the generic 3D model, assumed camera matrix, camera position, and pose calibration, participant-specific baseline orientation should be considered.

**Recommendation:** rename it `sustained_head_yaw_deviation`, establish a neutral forward-orientation baseline, and measure deviation from that baseline.

### 3. Sustained face absence

Face absence is a useful reviewability cue because it identifies periods where facial behavior cannot be observed. It does not distinguish leaving the camera view from face-detection failure, obstruction, poor lighting, or camera interruption.

**Recommendation:** retain it, but classify it as an observability or data-availability cue. Do not describe it as direct behavioral evidence without reviewing the corresponding video.

### 4. Simultaneous gaze and head deviation

The cue captures gaze and head flags within the same one-second window. This provides more context than either flag alone, but the two estimates are not fully independent because they use facial landmarks from the same video and can be affected by the same head rotation or tracking error.

**Recommendation:** retain it as a combined visual pattern. Avoid describing it as independent confirmation and test whether it adds information beyond the head cue alone.

### 5. Off-centre face with attention shift

This cue combines a large face-position offset with gaze or head deviation. Face position can provide useful context, but it is strongly affected by camera placement, seating position, and framing.

**Recommendation:** retain it as contextual metadata or use a participant-specific baseline. It should not be treated as a separate strong behavioral event merely because the participant was not centred in the frame.

### 6. Reduced face visibility context

The cue activates when the face occupies a small area of the frame during a gaze or head deviation. Small face area is primarily an observation-quality and camera-distance condition.

**Recommendation:** move this field from behavioral cue strength into a quality or reviewability section. It may justify cautious interpretation, but it should not independently increase suspicious-behavior evidence.

### 7. Hand near mouth

The rule measures two-dimensional wrist proximity to the midpoint of the mouth landmarks. It does not detect movement toward the mouth, physical contact, speaking, communication, or object use. A stationary hand can activate it, while a brief passing movement may not.

Only shoulder visibility is checked before the wrist-to-mouth calculation. Wrist and mouth visibility are not independently validated, and the fixed distance of 0.20 is measured relative to the entire frame. The same physical hand position can therefore produce different results under different camera distances.

**Recommendation:** require valid wrist and mouth landmarks, normalize wrist-to-mouth distance by shoulder width or another body-scale estimate, and preserve the neutral interpretation of proximity.

### 8. Elevated hands

The cue checks whether either wrist is above or close to its corresponding shoulder. It can describe relevant upper-body activity, but it can also reflect stretching, adjusting hair, touching the face, or incorrect wrist estimation.

**Recommendation:** retain it provisionally, add wrist-visibility checks, and represent left and right hands separately before forming the combined cue. Evaluate its false-activation rate through event-level annotation.

### 9. Upper-torso posture shift

This is the most important rule to revise. The feature is active in 7,916 of 8,868 windows. An examination of its component conditions shows:

- shoulder tilt exceeded its threshold in only 1 window;
- narrow shoulder width occurred in 9 windows;
- shoulder-center distance from frame centre exceeded 0.22 in all 7,916 activated windows.

The rule therefore detects that the shoulder midpoint is away from the image centre, usually because shoulders naturally appear below the middle of a webcam frame. It does not demonstrate a shift from a previous posture.

**Recommendation:** replace the rule with deviation from a calibrated participant baseline. Keep absolute frame position as a separate field such as `upper_torso_offcenter`, and reserve `posture_shift` for temporal change relative to an earlier or baseline posture.

### 10. High upper-torso movement

The feature measures shoulder-midpoint displacement between consecutive sampled frames. It does not divide displacement by elapsed time, so its meaning changes when FPS or sampling stride changes. The cue never activated in the current saved outputs.

**Recommendation:** calculate movement per second, verify the threshold at the fixed operational sampling rate, and determine whether the current threshold is too high.

### 11. Mouth activity with hand near mouth

The cue combines hand-near-mouth with mouth-opening activity within the same one-second window. It does not require the two conditions to occur in the same frame. The word “together” therefore means within the same aggregated second, not exact simultaneous occurrence.

**Recommendation:** retain it as a window-level co-occurrence or calculate direct frame-level overlap. Rename `mouth_movement` to `mouth_open` unless temporal mouth motion is actually calculated.

### 12. Multimodal corroboration

This is a meta-cue indicating that evidence was registered from at least two feature groups. It is not an independently observed behavior. Adding its own weight on top of the contributing cues can double-count the same physical action, particularly when head and gaze estimates respond to the same head turn.

**Recommendation:** preserve it as a Boolean or descriptive field, but test whether its additional 0.10 contribution improves screening performance. A safer design is to report the number and identity of active feature groups without automatically increasing cue strength.

## Proposed cue organization

The engine would be clearer if it separated behavioral observations, temporal patterns, contextual conditions, and meta-information.

### Behavioral observations

- horizontal gaze deviation
- head-yaw deviation
- mouth-open state
- hand near mouth
- elevated left or right hand
- upper-torso positional deviation
- upper-torso movement rate

### Temporal descriptors

- total active windows
- occurrence count
- longest consecutive duration
- mean occurrence duration
- first and last occurrence
- sustained condition
- repeated condition

### Context and quality conditions

- face absent
- gaze unavailable
- posture unavailable
- small face in frame
- low wrist visibility
- off-centre camera framing
- low modality coverage

### Multimodal relationships

- gaze and head deviation in the same window
- head and torso movement in the same window
- hand-near-mouth and mouth-open overlap
- number of feature groups active in the same window

This separation would prevent data-quality conditions and meta-cues from being presented as if they were direct behavioral observations.

## Recommended temporal additions

The compact MLLM JSON contains total cue counts, notable windows, and selected strong moments, but it does not explicitly describe every cue episode. Add an episode summary for each cue:

```json
{
  "cue": "hand_near_mouth",
  "occurrence_count": 3,
  "total_active_windows": 7,
  "longest_consecutive_windows": 4,
  "first_timestamp_sec": 482,
  "last_timestamp_sec": 864
}
```

This distinguishes one prolonged event from several separate events and gives the LLM explicit recurrence information instead of expecting it to infer recurrence from partial summaries.

## Cue-strength improvements

The present cue contributions are fixed heuristic values. The code does not show that a contribution of 0.20 is empirically twice as informative as a contribution of 0.10. The values should therefore be documented as design parameters used for information prioritization.

Recommended options are:

1. Obtain structured expert ratings for the relative review priority of each cue.
2. Perform sensitivity analysis using several reasonable weight configurations.
3. Compare conclusions when `multimodal_corroboration` and quality-related contributions are removed.
4. Conduct cue ablation analysis to determine whether each cue improves participant-level classification.
5. Freeze the selected rules and weights before evaluating new, unseen participants.

Learning weights from the existing 11 sessions may be useful for exploratory analysis, but it would not provide independent validation because feature and model choices have already been developed using these sessions.

## Plan for justifying the weights of all 12 cues

### What a valid justification must establish

Because MBIE is rule-based, the weights do not need to be learned by a classifier. They must, however, be assigned through a transparent and reproducible process. A defensible justification should explain:

1. why each cue is included;
2. what observable condition it represents;
3. why one cue receives greater or lower review priority than another;
4. how correlated cues and interaction cues are prevented from being counted repeatedly;
5. whether the conclusions remain stable under reasonable changes to the weights; and
6. how the fixed rules perform on participants who were not used to design them.

The present values in `CUE_CONTRIBUTIONS` are design choices. Explaining their apparent reasonableness after seeing the results would be a post-hoc rationale, not empirical validation. The procedure below should therefore be documented and applied before presenting a future weight set as justified.

### Step 1: freeze and correct the cue definitions

Weights cannot be justified while the underlying cue definitions are unstable or misleading. Before obtaining expert ratings or running sensitivity analysis:

- replace the current absolute-frame `upper_torso_posture_shift` rule with a baseline-relative rule;
- add wrist and mouth visibility requirements to `hand_near_mouth`;
- normalize hand distance by body scale;
- express upper-torso movement per unit of time;
- resolve duplicate global-second buckets at segment boundaries;
- rename head and gaze cues according to what they measure; and
- state whether interaction means exact frame overlap or co-occurrence within a one-second window.

The corrected cue definitions, thresholds, and extraction version should then be frozen for the weight study.

### Step 2: classify the 12 cues by function

The cues should not all be treated as equivalent additive evidence. Assign them to three functional groups:

#### Base behavioral cues

- `sustained_offscreen_gaze`
- `sustained_head_offscreen`
- `hand_near_mouth`
- `elevated_hands`
- `upper_torso_posture_shift`
- `high_upper_torso_movement`

These represent directly measured behavioral conditions and may receive base priority weights after correction and validation.

#### Interaction cues

- `simultaneous_gaze_and_head_offscreen`
- `mouth_activity_with_hand_near_mouth`
- `multimodal_corroboration`

These describe relationships among observations already represented by base cues. Their contributions should be smaller than the combined contributions of their components, or they should be reported descriptively without a numerical bonus. This prevents the same physical event from being counted several times.

#### Quality and contextual cues

- `sustained_face_absence`
- `offcenter_face_with_attention_shift`
- `reduced_face_visibility_context`

These primarily describe observability, camera framing, or interpretation quality. They should normally influence reviewability or generate a quality warning instead of increasing behavioral cue strength. If a numerical contribution is retained, it must be described as review priority rather than suspicious-behavior evidence.

### Step 3: prepare an evidence dossier for every cue

Create one record for each cue containing:

| Required field | Purpose |
|---|---|
| Operational definition | States exactly what activates the cue |
| Behavioral dimension | Identifies face/head, gaze, posture, quality, or interaction |
| Temporal condition | States whether it is instantaneous, sustained, repeated, or co-occurring |
| Measurement reliability | Records required landmarks and known failure conditions |
| Ambiguity | Lists legitimate behaviors that can produce the same observation |
| Literature relationship | Links the general cue type to references already used in the thesis |
| Dependency | Identifies cues that may arise from the same physical event |
| Proposed role | Base weight, interaction bonus, quality flag, or reviewability flag |
| Expert rating | Records the panel's agreed review-priority rating |
| Empirical behavior | Records prevalence, false activations, and event-level performance |
| Final contribution | Records the fixed contribution and rationale |

The examination studies already cited in the thesis can support the use of head, gaze, gesture, posture, and temporal combinations as observable information. They cannot by themselves justify the exact numerical contribution assigned by ARGUS-Lite.

### Step 4: obtain structured expert judgments

Use a small panel with relevant expertise, such as online-examination administration, behavioral observation, educational assessment, and computer vision. The panel should judge the cues as prompts for human review, not as proof of cheating.

Each expert should independently rate every corrected cue using the same criteria:

| Criterion | Question for the expert |
|---|---|
| Review relevance | If reliably observed, how useful is the cue for deciding where a reviewer should inspect the video? |
| Behavioral ambiguity | How many ordinary explanations could produce the observation? |
| Measurement reliability | How consistently can the available webcam analysis measure it? |
| Temporal importance | Does persistence or recurrence materially increase its review relevance? |
| Redundancy | How strongly does it overlap with another cue produced by the same action? |

A five-point ordinal scale can be used for each criterion. Experts should provide a short written reason for every rating. Use at least two rounds: independent ratings followed by a moderated review of disagreements. Report the number and backgrounds of experts, the rating instructions, the aggregation rule, and an agreement statistic such as Kendall's coefficient of concordance or an intraclass correlation where appropriate.

Pairwise comparison across all 12 cues would require 66 comparisons per expert and may cause fatigue. A more practical approach is a two-stage comparison: first compare the functional groups, then compare cues within each group.

### Step 5: convert expert judgments into provisional weights

Define the conversion rule before examining classification performance. One possible transparent procedure is:

1. reverse the ambiguity and redundancy ratings so that greater ambiguity or redundancy lowers priority;
2. average the selected criteria for each cue;
3. aggregate experts using the median to reduce the influence of extreme ratings;
4. normalize the resulting base-cue scores to a predefined base-weight budget;
5. assign a smaller, separate budget to interaction bonuses; and
6. keep quality/context conditions outside the behavioral-score budget.

For example, the engine could reserve most of its numerical range for corrected base behavioral cues, a limited portion for non-duplicative interactions, and no positive behavioral contribution for quality warnings. The exact budgets should be agreed before testing and reported. This is preferable to assigning a weight independently to every cue without controlling the total contribution of each functional group.

### Step 6: document the proposed treatment of each current cue

| Cue | Weight-justification question | Recommended treatment before validation |
|---|---|---|
| `sustained_offscreen_gaze` | Does sustained horizontal gaze deviation reliably identify periods worth reviewing beyond ordinary brief gaze changes? | Base cue after gaze calibration and quality checks |
| `sustained_head_offscreen` | Does persistent yaw deviation add review value after accounting for normal head orientation and camera placement? | Base cue after baseline correction; reduce for correlation with gaze |
| `sustained_face_absence` | Is the objective behavioral suspicion or inability to observe the participant? | Reviewability/visibility flag; avoid treating as direct behavioral evidence |
| `simultaneous_gaze_and_head_offscreen` | Does co-occurrence add information beyond the two component cues? | Small interaction bonus or descriptive field; test for double counting |
| `offcenter_face_with_attention_shift` | Is the face offset participant behavior or static camera framing? | Context field unless baseline-relative displacement is implemented |
| `reduced_face_visibility_context` | Does a small face indicate behavior or reduced measurement quality? | Quality warning with no positive behavioral weight |
| `hand_near_mouth` | After reliable landmark and scale correction, how often does this cue identify a review-relevant visible action? | Base cue with moderate priority because legitimate explanations are common |
| `elevated_hands` | Is the hand elevation reliably visible and sufficiently uncommon during legitimate examination activity? | Low-priority base cue after visibility validation |
| `upper_torso_posture_shift` | Does the revised rule measure change from baseline rather than frame position? | Do not justify the current weight; redesign first |
| `high_upper_torso_movement` | Does time-normalized movement identify meaningful movement episodes at the operational sampling rate? | Base cue only after the inactive rule is recalibrated |
| `mouth_activity_with_hand_near_mouth` | Does true temporal overlap add review value beyond mouth-open and hand-proximity observations? | Small interaction bonus after frame-level overlap is implemented |
| `multimodal_corroboration` | Does an extra bonus improve prioritization without counting correlated observations twice? | Prefer descriptive metadata; justify any bonus through ablation and sensitivity analysis |

### Step 7: validate cue detection independently of session labels

Human annotators should mark the occurrence and duration of the observable events themselves. For example, they should annotate “right wrist visibly close to mouth” or “head turned away from calibrated forward direction,” without deciding whether the participant was cheating.

For each cue, calculate:

- precision;
- recall;
- F1 score;
- false activations per minute;
- missed events per minute;
- temporal intersection-over-union or onset/offset tolerance; and
- performance across participants and camera conditions.

Reliability estimates can then inform the expert-derived priorities. A cue with low measurement reliability should not receive a large contribution even if experts consider the underlying behavior relevant.

### Step 8: test redundancy and double counting

Calculate co-activation rates and correlations among cues. Review combinations such as:

- sustained gaze deviation with sustained head deviation;
- head deviation with face offset;
- hand near mouth with elevated hands;
- hand near mouth with mouth activity; and
- all base cues with `multimodal_corroboration`.

Run an ablation analysis in which each cue or interaction bonus is removed in turn. If removing an interaction cue does not change timestamp prioritization or participant-level performance, its numerical contribution is unnecessary. If two cues almost always activate together, reduce one contribution or represent their relationship as a single combined rule.

### Step 9: perform sensitivity analysis

After defining provisional weights, vary each base weight and interaction bonus by a prespecified amount, such as plus or minus 10%, 20%, and 30%. Recalculate:

- ranked review timestamps;
- notable and strong window counts;
- session-level LLM inputs;
- final classifications;
- false-positive and false-negative counts; and
- agreement between the original and perturbed rankings.

If small weight changes substantially alter the conclusions, the engine is weight-sensitive and the results should be reported as unstable. If the main conclusions remain consistent across a reasonable range, the sensitivity analysis provides evidence that the selected values are not arbitrary single-point choices.

### Step 10: freeze and evaluate on unseen participants

After cue definitions, thresholds, and contributions are finalized, record them in a versioned configuration and do not adjust them using the evaluation participants. Apply the fixed rule engine to additional unseen examination sessions. Report both cue-level event detection and session-level screening performance.

This final stage is necessary because the current 11 sessions were already used during system development. Cross-validation on those sessions can describe preliminary performance but cannot provide fully independent confirmation of the selected rules or weights.

### Recommended justification statement for the thesis

If the structured expert-rating, event-validation, redundancy, and sensitivity steps have not yet been completed, use cautious wording:

> The cue contributions used by MBIE were predefined heuristic values used to prioritize information-dense behavioral periods. Their relative magnitudes reflected the intended review priority of sustained, combined, and posture-related observations, but they were not learned probabilities or independently validated measures of cheating likelihood. The study therefore evaluates them as proof-of-concept rule-engine parameters and identifies formal expert elicitation, event-level annotation, sensitivity analysis, and validation on unseen participants as requirements for future calibration.

If the full procedure is completed, the thesis can instead state that the weights were derived through a documented expert-consensus procedure, checked against independently annotated behavioral events, tested for redundancy and sensitivity, frozen before evaluation, and assessed on unseen sessions. The thesis should still avoid interpreting the weights as probabilities of academic dishonesty.

## Required cue-validation study

Session-level scripted labels cannot establish whether individual cues are correctly detected. Cue validation requires event-level reference annotations.

A suitable validation procedure would be:

1. Select video samples covering different participants, lighting conditions, camera positions, and examination conditions.
2. Define each observable event operationally without referring to cheating intent.
3. Ask at least two human annotators to independently mark event start and end times.
4. Measure inter-rater agreement before using the annotations as reference data.
5. Compare each rule with the reference annotations using event-level precision, recall, F1, false activations per minute, and timing overlap.
6. Tune thresholds only on a development subset.
7. Evaluate the frozen rules on unseen participants and sessions.

This process can verify whether `hand_near_mouth` detects visible hand proximity, whether head-yaw rules detect sustained orientation changes, and whether posture rules detect actual posture changes. It still would not prove that those behaviors represent cheating.

## Implementation priorities

### Priority 1: correct before regenerating results

1. Replace the absolute frame-centre posture-shift rule with baseline-relative posture deviation.
2. Prevent duplicate one-second buckets at segment boundaries.
3. Require wrist and mouth landmark visibility for hand-related cues.
4. Normalize movement by elapsed time and hand distance by body scale.

### Priority 2: improve interpretation and temporal representation

5. Add occurrence counts and longest consecutive duration for every cue.
6. Move face-size and camera-framing conditions into quality/context fields.
7. Remove or justify the additional `multimodal_corroboration` weight.
8. Rename cues so that their names match their actual measurements.

### Priority 3: validate and document

9. Annotate behavioral events independently.
10. Measure cue-level performance and inter-rater agreement.
11. Perform weight sensitivity and cue-ablation analyses.
12. Validate frozen rules on additional unseen participants.

## Thesis wording recommendation

The implemented component can be described as follows:

> MBIE is a deterministic, rule-based temporal fusion component that organizes timestamped face/head, gaze, and upper-torso observations into one-second behavioral-cue summaries. Its active cues and cue-strength values are produced through predefined thresholds and heuristic contributions rather than a trained behavioral classifier. These outputs prioritize observable periods for subsequent interpretation and human review; they do not represent probabilities of cheating or confirmation of academic dishonesty.

Existing examination studies cited in the thesis, including Arinaldi and Fanany (2017), Ferdosi et al. (2023), Tran et al. (2023), and Liu et al. (2024), support analyzing behavioral sequences and combinations of visual features. They do not validate ARGUS-Lite's exact thresholds, cue definitions, or cue-strength contributions. Those implementation choices require separate empirical validation.

