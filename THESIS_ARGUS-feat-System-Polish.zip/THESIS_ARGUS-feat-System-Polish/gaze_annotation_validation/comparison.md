# Comparison of video annotations and saved gaze JSON

Compared 160 annotated intervals for P01, P08, and P10 with 36 existing gaze segment files.

Main finding: every annotated center interval was predominantly labeled center, but only 1 of 13 annotated sideways intervals was predominantly labeled with its annotated direction. All 10 right-looking intervals (P08 and P10) were entirely labeled center. This is interval-level majority agreement, not frame-level accuracy or a validated detection score.

The comparison does not validate 7 and 12 as reliable thresholds. It suggests that the present center category absorbs many annotated sideways looks. Possible causes include the thresholds, gaze measurement, head movement, camera setup, annotation conventions, or synchronization. The comparison alone cannot isolate the cause.

All samples in timestamp intervals [start,end); durations use timestamp endpoints, not prose. No time-offset correction. Counts are sample-based, not exact duration. Down is unsupported and excluded from horizontal agreement.

Source PDF: C:\Users\sebastien\Downloads\Data Validation - Sheet1.pdf

## Full-output summary

| Examinee | Files | Samples | Categories | Largest absolute estimate |
|---|---:|---:|---|---:|
| P01 | 15 | 12999 | {'center': 12037, 'offscreen': 85, 'left': 842, 'right': 20, 'no_gaze': 15} | 33.11 |
| P08 | 14 | 12308 | {'center': 12232, 'left': 31, 'offscreen': 45} | 36.1 |
| P10 | 7 | 5828 | {'center': 5808, 'right': 16, 'offscreen': 2, 'left': 2} | 12.48 |

## Agreement within annotated periods

| Examinee | Annotation | Intervals | Seconds | JSON sample categories |
|---|---|---:|---:|---|
| P01 | center | 43 | 362 | {'center': 5384, 'left': 54} |
| P01 | left | 2 | 12 | {'center': 121, 'left': 59} |
| P01 | down | 19 | 149 | {'center': 1699, 'left': 497, 'offscreen': 33, 'right': 8} |
| P08 | center | 35 | 268 | {'center': 4021, 'left': 2} |
| P08 | left | 1 | 4 | {'center': 43, 'left': 10, 'offscreen': 7} |
| P08 | right | 6 | 36 | {'center': 540} |
| P08 | down | 20 | 108 | {'center': 1620} |
| P10 | center | 25 | 113 | {'center': 1579} |
| P10 | right | 4 | 21 | {'center': 294} |
| P10 | down | 5 | 19 | {'center': 263, 'right': 2} |

## Every annotated interval

| Examinee | Time | Annotation | Samples | JSON categories | Estimate range | Exact agreement |
|---|---|---|---:|---|---|---|
| P01 | 0:02-0:05 | center | 45 | {'center': 45} | -1.93 to 0.83 | 100.0% |
| P01 | 0:06-0:09 | center | 45 | {'center': 45} | -1.63 to 0.49 | 100.0% |
| P01 | 0:12-0:18 | center | 90 | {'center': 90} | -1.84 to 0.81 | 100.0% |
| P01 | 0:19-0:29 | center | 150 | {'center': 150} | -3.54 to -0.1 | 100.0% |
| P01 | 0:37-0:40 | center | 45 | {'center': 45} | -1.34 to 1.55 | 100.0% |
| P01 | 0:42-0:43 | center | 15 | {'center': 15} | 0.12 to 1.78 | 100.0% |
| P01 | 0:45-0:51 | down | 90 | {'center': 53, 'left': 37} | -9.78 to 0.82 | Unsupported |
| P01 | 0:53-1:01 | down | 121 | {'center': 78, 'left': 43} | -11.22 to -2.05 | Unsupported |
| P01 | 1:05-1:15 | center | 150 | {'center': 150} | -3.57 to -0.32 | 100.0% |
| P01 | 1:18-1:22 | center | 60 | {'center': 60} | -2.26 to -0.51 | 100.0% |
| P01 | 1:26-1:30 | center | 60 | {'center': 60} | -3.55 to 0.19 | 100.0% |
| P01 | 1:30-1:35 | center | 75 | {'center': 62, 'left': 13} | -10.33 to 1.35 | 82.7% |
| P01 | 1:36-2:26 | down | 751 | {'center': 493, 'left': 220, 'offscreen': 33, 'right': 5} | -17.46 to 10.0 | Unsupported |
| P01 | 2:39-2:42 | down | 45 | {'center': 45} | -2.12 to 3.25 | Unsupported |
| P01 | 2:42-2:45 | center | 45 | {'center': 45} | -2.4 to -0.08 | 100.0% |
| P01 | 2:48-2:59 | center | 166 | {'center': 166} | -3.85 to 0.13 | 100.0% |
| P01 | 3:05-3:12 | down | 105 | {'center': 36, 'left': 69} | -9.72 to -0.13 | Unsupported |
| P01 | 3:18-3:21 | down | 45 | {'left': 44, 'center': 1} | -10.39 to -4.85 | Unsupported |
| P01 | 3:22-3:32 | center | 150 | {'center': 145, 'left': 5} | -7.37 to 1.21 | 96.7% |
| P01 | 3:40-3:47 | left | 105 | {'center': 87, 'left': 18} | -7.54 to -0.05 | 17.1% |
| P01 | 3:48-3:57 | center | 136 | {'center': 118, 'left': 18} | -8.05 to 0.78 | 86.8% |
| P01 | 4:04-4:09 | center | 75 | {'center': 57, 'left': 18} | -8.69 to -0.11 | 76.0% |
| P01 | 4:11-4:17 | down | 90 | {'center': 80, 'left': 10} | -7.87 to 1.45 | Unsupported |
| P01 | 4:17-4:21 | down | 60 | {'center': 40, 'left': 20} | -8.61 to -0.0 | Unsupported |
| P01 | 4:30-4:36 | down | 90 | {'center': 76, 'left': 14} | -8.64 to -1.44 | Unsupported |
| P01 | 4:43-4:47 | down | 60 | {'center': 57, 'left': 3} | -8.36 to -1.34 | Unsupported |
| P01 | 4:49-4:52 | down | 45 | {'center': 45} | -5.99 to 0.3 | Unsupported |
| P01 | 4:52-4:55 | center | 45 | {'center': 45} | -2.5 to 1.39 | 100.0% |
| P01 | 5:00-5:11 | down | 165 | {'center': 161, 'left': 4} | -7.92 to -0.69 | Unsupported |
| P01 | 5:12-5:15 | center | 45 | {'center': 45} | -2.51 to -0.8 | 100.0% |
| P01 | 5:16-5:24 | down | 120 | {'center': 118, 'left': 2} | -7.43 to -1.33 | Unsupported |
| P01 | 5:26-5:31 | down | 75 | {'center': 75} | -6.29 to -3.18 | Unsupported |
| P01 | 5:47-5:50 | down | 45 | {'center': 36, 'left': 9} | -7.81 to -0.31 | Unsupported |
| P01 | 5:51-5:54 | down | 45 | {'center': 23, 'left': 22} | -8.5 to 0.13 | Unsupported |
| P01 | 6:08-6:19 | center | 165 | {'center': 165} | -3.18 to 4.02 | 100.0% |
| P01 | 6:27-6:32 | left | 75 | {'center': 34, 'left': 41} | -9.09 to 0.02 | 54.7% |
| P01 | 7:24-7:28 | center | 60 | {'center': 60} | -2.46 to 1.27 | 100.0% |
| P01 | 7:30-7:37 | center | 105 | {'center': 105} | -2.72 to 2.62 | 100.0% |
| P01 | 7:38-7:42 | center | 61 | {'center': 61} | -2.73 to 0.89 | 100.0% |
| P01 | 7:43-8:05 | center | 330 | {'center': 330} | -2.86 to 1.5 | 100.0% |
| P01 | 8:16-8:20 | center | 60 | {'center': 60} | -2.35 to 1.1 | 100.0% |
| P01 | 8:37-8:54 | center | 256 | {'center': 256} | -3.85 to 0.36 | 100.0% |
| P01 | 8:59-9:05 | center | 90 | {'center': 90} | -3.78 to 0.25 | 100.0% |
| P01 | 9:11-9:35 | center | 360 | {'center': 360} | -3.21 to 3.96 | 100.0% |
| P01 | 9:41-9:46 | down | 75 | {'right': 3, 'center': 72} | -5.9 to 9.49 | Unsupported |
| P01 | 9:47-9:55 | center | 120 | {'center': 120} | -3.35 to 3.81 | 100.0% |
| P01 | 9:58-10:10 | center | 180 | {'center': 180} | -3.03 to 1.4 | 100.0% |
| P01 | 10:16-10:28 | center | 180 | {'center': 180} | -5.59 to 0.32 | 100.0% |
| P01 | 10:32-10:43 | center | 166 | {'center': 166} | -4.0 to 1.27 | 100.0% |
| P01 | 10:44-10:51 | center | 105 | {'center': 105} | -2.88 to 0.31 | 100.0% |
| P01 | 10:54-11:08 | center | 210 | {'center': 210} | -3.77 to 1.35 | 100.0% |
| P01 | 11:10-11:22 | center | 180 | {'center': 180} | -3.09 to 0.83 | 100.0% |
| P01 | 11:24-11:30 | center | 90 | {'center': 90} | -4.68 to 1.87 | 100.0% |
| P01 | 11:31-11:54 | center | 346 | {'center': 346} | -3.54 to 1.17 | 100.0% |
| P01 | 11:54-12:06 | center | 180 | {'center': 180} | -2.84 to 2.47 | 100.0% |
| P01 | 12:06-12:10 | center | 60 | {'center': 60} | -4.26 to 0.74 | 100.0% |
| P01 | 12:13-12:17 | center | 60 | {'center': 60} | -2.31 to 0.56 | 100.0% |
| P01 | 12:27-12:39 | center | 181 | {'center': 181} | -3.48 to 1.11 | 100.0% |
| P01 | 12:40-12:43 | center | 45 | {'center': 45} | -2.42 to 0.77 | 100.0% |
| P01 | 12:45-12:53 | center | 120 | {'center': 120} | -3.17 to 2.8 | 100.0% |
| P01 | 12:54-13:04 | center | 150 | {'center': 150} | -3.43 to 0.86 | 100.0% |
| P01 | 13:17-13:29 | center | 181 | {'center': 181} | -4.13 to 1.48 | 100.0% |
| P01 | 13:52-13:59 | down | 105 | {'center': 105} | -5.89 to 2.5 | Unsupported |
| P01 | 14:04-14:11 | down | 105 | {'center': 105} | -2.82 to 0.77 | Unsupported |
| P08 | 0:23-0:30 | center | 105 | {'center': 105} | -1.35 to 2.33 | 100.0% |
| P08 | 0:33-0:47 | center | 210 | {'center': 210} | -3.91 to 1.37 | 100.0% |
| P08 | 0:49-0:52 | center | 45 | {'center': 45} | -1.12 to 2.26 | 100.0% |
| P08 | 0:52-0:55 | down | 45 | {'center': 45} | 0.68 to 2.16 | Unsupported |
| P08 | 1:14-1:18 | right | 60 | {'center': 60} | 0.78 to 3.59 | 0.0% |
| P08 | 1:29-2:04 | center | 526 | {'left': 2, 'center': 524} | -11.34 to 4.28 | 99.6% |
| P08 | 2:12-2:17 | center | 75 | {'center': 75} | -1.78 to 2.91 | 100.0% |
| P08 | 2:24-2:27 | down | 45 | {'center': 45} | 1.04 to 4.16 | Unsupported |
| P08 | 2:31-2:37 | right | 90 | {'center': 90} | 1.98 to 5.12 | 0.0% |
| P08 | 2:37-2:43 | right | 90 | {'center': 90} | 0.27 to 4.53 | 0.0% |
| P08 | 2:51-2:58 | center | 105 | {'center': 105} | -1.85 to 1.81 | 100.0% |
| P08 | 3:05-3:08 | center | 45 | {'center': 45} | -2.88 to 1.21 | 100.0% |
| P08 | 3:13-3:17 | center | 60 | {'center': 60} | -2.61 to 5.29 | 100.0% |
| P08 | 3:17-3:20 | down | 45 | {'center': 45} | -2.16 to 4.48 | Unsupported |
| P08 | 3:32-3:38 | right | 90 | {'center': 90} | 0.0 to 4.56 | 0.0% |
| P08 | 3:40-3:44 | down | 60 | {'center': 60} | 0.39 to 4.44 | Unsupported |
| P08 | 3:48-3:56 | down | 120 | {'center': 120} | 0.98 to 4.55 | Unsupported |
| P08 | 3:59-4:02 | down | 45 | {'center': 45} | -1.51 to 3.51 | Unsupported |
| P08 | 4:04-4:08 | down | 60 | {'center': 60} | -1.99 to 4.65 | Unsupported |
| P08 | 4:19-4:25 | down | 90 | {'center': 90} | -2.46 to 4.32 | Unsupported |
| P08 | 4:39-4:43 | center | 60 | {'center': 60} | -2.22 to 4.45 | 100.0% |
| P08 | 4:46-4:52 | down | 90 | {'center': 90} | -2.36 to 4.31 | Unsupported |
| P08 | 4:59-5:09 | right | 150 | {'center': 150} | -1.08 to 4.06 | 0.0% |
| P08 | 5:12-5:18 | down | 90 | {'center': 90} | -2.65 to 4.96 | Unsupported |
| P08 | 5:49-5:53 | center | 60 | {'center': 60} | -2.6 to 1.26 | 100.0% |
| P08 | 5:54-6:05 | center | 165 | {'center': 165} | -2.32 to 2.01 | 100.0% |
| P08 | 6:08-6:13 | center | 75 | {'center': 75} | -1.77 to 2.19 | 100.0% |
| P08 | 6:24-6:29 | center | 75 | {'center': 75} | 0.63 to 1.55 | 100.0% |
| P08 | 6:29-6:32 | down | 45 | {'center': 45} | -0.25 to 2.52 | Unsupported |
| P08 | 6:40-6:44 | down | 60 | {'center': 60} | -3.45 to 2.7 | Unsupported |
| P08 | 6:44-6:48 | center | 60 | {'center': 60} | -1.68 to 2.81 | 100.0% |
| P08 | 6:48-6:55 | down | 105 | {'center': 105} | -1.78 to 1.33 | Unsupported |
| P08 | 6:56-7:16 | down | 300 | {'center': 300} | -1.01 to 1.41 | Unsupported |
| P08 | 7:17-7:22 | down | 75 | {'center': 75} | -0.94 to 1.22 | Unsupported |
| P08 | 7:53-8:03 | center | 150 | {'center': 150} | -1.48 to 4.61 | 100.0% |
| P08 | 8:08-8:11 | center | 45 | {'center': 45} | -0.24 to 3.9 | 100.0% |
| P08 | 8:13-8:17 | left | 60 | {'center': 43, 'left': 10, 'offscreen': 7} | -36.1 to 1.26 | 16.7% |
| P08 | 8:22-8:25 | center | 45 | {'center': 45} | -2.72 to 2.95 | 100.0% |
| P08 | 8:43-8:49 | center | 90 | {'center': 90} | -2.45 to 1.31 | 100.0% |
| P08 | 8:53-9:09 | center | 240 | {'center': 240} | -1.37 to 1.44 | 100.0% |
| P08 | 9:15-9:21 | center | 90 | {'center': 90} | -0.72 to 3.82 | 100.0% |
| P08 | 9:30-9:33 | center | 45 | {'center': 45} | -1.62 to 2.84 | 100.0% |
| P08 | 9:37-9:42 | down | 75 | {'center': 75} | -2.52 to 1.05 | Unsupported |
| P08 | 9:50-9:53 | down | 45 | {'center': 45} | 1.06 to 3.18 | Unsupported |
| P08 | 9:57-10:02 | down | 75 | {'center': 75} | -0.48 to 3.88 | Unsupported |
| P08 | 10:21-10:29 | center | 121 | {'center': 121} | -1.33 to 1.52 | 100.0% |
| P08 | 10:36-10:48 | center | 180 | {'center': 180} | -2.13 to 4.38 | 100.0% |
| P08 | 10:49-10:53 | center | 60 | {'center': 60} | -1.79 to 6.59 | 100.0% |
| P08 | 11:00-11:14 | center | 210 | {'center': 210} | -3.6 to 1.54 | 100.0% |
| P08 | 11:18-11:28 | center | 151 | {'center': 151} | -3.14 to 1.83 | 100.0% |
| P08 | 11:29-11:36 | center | 105 | {'center': 105} | -2.54 to 1.23 | 100.0% |
| P08 | 11:41-11:47 | center | 90 | {'center': 90} | -2.34 to 4.25 | 100.0% |
| P08 | 11:51-11:56 | center | 75 | {'center': 75} | -1.89 to 3.45 | 100.0% |
| P08 | 11:56-12:03 | center | 105 | {'center': 105} | -2.44 to 3.92 | 100.0% |
| P08 | 12:04-12:15 | center | 165 | {'center': 165} | -2.1 to 3.62 | 100.0% |
| P08 | 12:23-12:27 | right | 60 | {'center': 60} | -0.69 to 1.49 | 0.0% |
| P08 | 12:27-12:40 | center | 195 | {'center': 195} | -2.39 to 1.41 | 100.0% |
| P08 | 12:50-12:56 | center | 90 | {'center': 90} | -2.59 to 2.9 | 100.0% |
| P08 | 12:57-13:01 | center | 60 | {'center': 60} | -1.8 to 1.13 | 100.0% |
| P08 | 13:06-13:09 | center | 45 | {'center': 45} | -2.16 to 2.16 | 100.0% |
| P08 | 13:26-13:31 | down | 75 | {'center': 75} | -2.09 to 1.94 | Unsupported |
| P08 | 13:34-13:39 | down | 75 | {'center': 75} | -4.2 to 1.39 | Unsupported |
| P10 | 0:20-0:25 | center | 70 | {'center': 70} | -1.92 to 0.16 | 100.0% |
| P10 | 0:27-0:35 | center | 112 | {'center': 112} | -0.86 to 1.12 | 100.0% |
| P10 | 0:44-0:48 | down | 56 | {'center': 56} | -1.95 to 0.28 | Unsupported |
| P10 | 1:02-1:06 | center | 55 | {'center': 55} | -1.89 to 1.0 | 100.0% |
| P10 | 1:10-1:15 | right | 70 | {'center': 70} | -1.18 to 4.54 | 0.0% |
| P10 | 1:25-1:28 | center | 42 | {'center': 42} | -2.09 to 3.25 | 100.0% |
| P10 | 1:38-1:41 | center | 42 | {'center': 42} | -4.64 to 3.16 | 100.0% |
| P10 | 1:44-1:48 | down | 56 | {'center': 56} | -4.4 to 1.13 | Unsupported |
| P10 | 2:09-2:13 | right | 56 | {'center': 56} | -2.34 to 1.77 | 0.0% |
| P10 | 2:27-2:36 | center | 126 | {'center': 126} | -3.63 to 4.94 | 100.0% |
| P10 | 2:55-2:59 | center | 56 | {'center': 56} | -3.38 to 2.39 | 100.0% |
| P10 | 3:04-3:09 | center | 70 | {'center': 70} | -3.19 to 1.92 | 100.0% |
| P10 | 3:17-3:23 | center | 84 | {'center': 84} | -3.21 to 2.19 | 100.0% |
| P10 | 3:27-3:36 | right | 126 | {'center': 126} | -3.74 to 1.33 | 0.0% |
| P10 | 3:36-3:40 | center | 55 | {'center': 55} | -1.66 to 2.5 | 100.0% |
| P10 | 3:40-3:43 | right | 42 | {'center': 42} | -1.18 to 2.59 | 0.0% |
| P10 | 3:46-3:52 | center | 84 | {'center': 84} | -0.27 to 2.85 | 100.0% |
| P10 | 3:53-3:57 | center | 56 | {'center': 56} | -1.49 to 2.33 | 100.0% |
| P10 | 4:04-4:08 | center | 56 | {'center': 56} | -2.36 to 0.0 | 100.0% |
| P10 | 4:16-4:20 | center | 56 | {'center': 56} | -2.03 to 1.67 | 100.0% |
| P10 | 4:20-4:23 | down | 42 | {'center': 42} | -2.58 to 2.59 | Unsupported |
| P10 | 4:25-4:28 | down | 41 | {'center': 41} | -1.45 to 1.85 | Unsupported |
| P10 | 4:30-4:34 | center | 56 | {'center': 56} | -1.61 to 2.69 | 100.0% |
| P10 | 4:35-4:42 | center | 98 | {'center': 98} | -1.08 to 2.43 | 100.0% |
| P10 | 5:13-5:18 | down | 70 | {'center': 68, 'right': 2} | -5.9 to 10.7 | Unsupported |
| P10 | 5:40-5:43 | center | 42 | {'center': 42} | -0.39 to 3.58 | 100.0% |
| P10 | 6:01-6:05 | center | 56 | {'center': 56} | -2.87 to 2.2 | 100.0% |
| P10 | 6:05-6:09 | center | 56 | {'center': 56} | -3.28 to 1.86 | 100.0% |
| P10 | 6:09-6:12 | center | 41 | {'center': 41} | -2.06 to 2.31 | 100.0% |
| P10 | 6:13-6:16 | center | 42 | {'center': 42} | -3.58 to 2.58 | 100.0% |
| P10 | 6:18-6:21 | center | 42 | {'center': 42} | -2.07 to 2.9 | 100.0% |
| P10 | 6:23-6:27 | center | 56 | {'center': 56} | -3.21 to 2.3 | 100.0% |
| P10 | 6:29-6:34 | center | 70 | {'center': 70} | -3.27 to 1.6 | 100.0% |
| P10 | 6:52-6:56 | center | 56 | {'center': 56} | -2.58 to 2.06 | 100.0% |

## Annotation issues

Obvious spelling errors were normalized. Timestamp endpoints were used when the written duration disagreed.
- {'participant': 'P01', 'page': 1, 'interval': '0:19-0:29', 'start': 19, 'end': 29, 'label': 'center', 'stated_duration': 6, 'original': '0:19-0:29 The examinee was looking center for 6 seconds.'}
- {'participant': 'P01', 'page': 1, 'interval': '0:42-0:43', 'start': 42, 'end': 43, 'label': 'center', 'stated_duration': 3, 'original': '0:42-0:43 The examinee was looking center for 3 seconds.'}
- {'participant': 'P01', 'page': 2, 'interval': '6:08-6:19', 'start': 368, 'end': 379, 'label': 'center', 'stated_duration': 11, 'original': '6:08-6:19 The examinee was looking cemter for 11 seconds.'}
- {'participant': 'P01', 'page': 2, 'interval': '9:11-9:35', 'start': 551, 'end': 575, 'label': 'center', 'stated_duration': 23, 'original': '9:11-9:35 The examinee was looking center for 23 seconds.'}
- {'participant': 'P08', 'page': 4, 'interval': '9:15-9:21', 'start': 555, 'end': 561, 'label': 'center', 'stated_duration': 6, 'original': '9:15-9-21 The examinee was looking center for 6 seconds.'}
- {'participant': 'P10', 'page': 5, 'interval': '3:40-3:43', 'start': 220, 'end': 223, 'label': 'right', 'stated_duration': 3, 'original': '3:40-3:43 The examinee was looking rightr for 3 seconds.'}
- {'participant': 'P10', 'page': 5, 'interval': '6:52-6:56', 'start': 412, 'end': 416, 'label': 'center', 'stated_duration': 3, 'original': '6:52-6:56 The examinee was looking center for 3 seconds.'}

## Interpretation limits

- Center measures horizontal position only, so it does not rule out looking down.
- The annotations contain center, left, right, and down; no explicit offscreen labels. They cannot establish the correct offscreen threshold.
- Agreement with center alone does not validate the center threshold: the ability to distinguish sideways observations must also be checked.
- This compares annotations with existing JSON, without independently watching the source videos or verifying synchronization.
- No extractor parameters or existing outputs were changed.
