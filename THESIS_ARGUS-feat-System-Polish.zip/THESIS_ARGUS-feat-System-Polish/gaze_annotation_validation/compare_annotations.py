"""Read-only comparison of PDF annotations with existing gaze extractor outputs."""
import json
import re
from collections import Counter
from pathlib import Path
from statistics import median
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
PDF = Path(r'C:\Users\sebastien\Downloads\Data Validation - Sheet1.pdf')
annotations, issues = [], []
participant = None
def seconds(value):
    m, s = map(int, value.split(':'))
    return 60*m+s
for page_num, page in enumerate(PdfReader(PDF).pages, 1):
    for line in page.extract_text().splitlines():
        line = line.strip()
        if re.fullmatch(r'P\d\d', line):
            participant = line
        match = re.fullmatch(r'(\d+:\d+)\s*-\s*(\d+[:-]\d+)\s+The examinee was looking (\w+) for (\d+) seconds\.', line)
        if not match:
            if 'The examinee' in line:
                issues.append({'unparsed': line, 'page': page_num})
            continue
        start, end, label, duration = match.groups()
        corrected_end = end.replace('-', ':')
        corrected_label = {'cemter':'center', 'rightr':'right'}.get(label, label)
        a = {'participant':participant, 'page':page_num, 'interval':f'{start}-{corrected_end}',
             'start':seconds(start), 'end':seconds(corrected_end), 'label':corrected_label,
             'stated_duration':int(duration), 'original':line}
        if a['end']-a['start'] != int(duration) or label != corrected_label or end != corrected_end:
            issues.append(a.copy())
        annotations.append(a)

all_events, summaries = {}, {}
for pid in sorted({a['participant'] for a in annotations}):
    paths = sorted((ROOT/f'EXAM-{pid}'/f'EXAM-{pid}_gaze_segments').glob('gaze_segment_*.json'))
    events = []
    configs = []
    for path in paths:
        obj = json.loads(path.read_text())
        configs.append((obj.get('center_angle_deg'), obj.get('offscreen_angle_deg')))
        for e in obj['events']:
            events.append(dict(e, source=str(path.relative_to(ROOT))))
    events.sort(key=lambda e:e['timestamp_sec'])
    all_events[pid] = events
    summaries[pid] = {'files':len(paths), 'thresholds':sorted(set(configs)),
        'samples':len(events),'regions':dict(Counter(e['gaze_region'] for e in events)),
        'max_abs_angle':max(abs(e['gaze_angle_deg']) for e in events if e.get('gaze_angle_deg') is not None),
        'last_timestamp':events[-1]['timestamp_sec']}

rows = []
for a in annotations:
    samples = [e for e in all_events[a['participant']] if a['start'] <= e['timestamp_sec'] < a['end']]
    counts = Counter(e['gaze_region'] for e in samples)
    angles = [e['gaze_angle_deg'] for e in samples if e.get('gaze_angle_deg') is not None]
    rows.append(dict(a, samples=len(samples), counts=dict(counts),
        dominant=counts.most_common(1)[0][0] if counts else None,
        exact_match_pct=100*counts[a['label']]/len(samples) if samples and a['label']!='down' else None,
        min_angle=min(angles) if angles else None, max_angle=max(angles) if angles else None,
        median_angle=median(angles) if angles else None,
        source_files=sorted({e['source'] for e in samples})))

totals = {}
for pid in summaries:
    totals[pid] = {}
    for label in ['center','left','right','down']:
        group = [r for r in rows if r['participant']==pid and r['label']==label]
        counts = Counter()
        for r in group: counts.update(r['counts'])
        totals[pid][label] = {'intervals':len(group),'seconds':sum(r['end']-r['start'] for r in group),
            'samples':sum(counts.values()),'counts':dict(counts),
            'dominant_match_intervals':sum(r['dominant']==label for r in group) if label!='down' else None}

result = {'method':'All samples in timestamp intervals [start,end); durations use timestamp endpoints, not prose. No time-offset correction. Counts are sample-based, not exact duration. Down is unsupported and excluded from horizontal agreement.',
          'summaries':summaries,'totals':totals,'annotation_issues':issues,'intervals':rows}
(OUT/'comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
md = ['# Comparison of video annotations and saved gaze JSON','',
      'Compared 160 annotated intervals for P01, P08, and P10 with 36 existing gaze segment files.', '',
      'Main finding: every annotated center interval was predominantly labeled center, but only 1 of 13 annotated sideways intervals was predominantly labeled with its annotated direction. All 10 right-looking intervals (P08 and P10) were entirely labeled center. This is interval-level majority agreement, not frame-level accuracy or a validated detection score.', '',
      'The comparison does not validate 7 and 12 as reliable thresholds. It suggests that the present center category absorbs many annotated sideways looks. Possible causes include the thresholds, gaze measurement, head movement, camera setup, annotation conventions, or synchronization. The comparison alone cannot isolate the cause.', '',
      result['method'],'',
      'Source PDF: '+str(PDF),'','## Full-output summary','',
      '| Examinee | Files | Samples | Categories | Largest absolute estimate |','|---|---:|---:|---|---:|']
for pid,s in summaries.items():
    md.append(f"| {pid} | {s['files']} | {s['samples']} | {s['regions']} | {s['max_abs_angle']} |")
md += ['','## Agreement within annotated periods','',
       '| Examinee | Annotation | Intervals | Seconds | JSON sample categories |','|---|---|---:|---:|---|']
for pid, groups in totals.items():
    for label,g in groups.items():
        if g['intervals']: md.append(f"| {pid} | {label} | {g['intervals']} | {g['seconds']} | {g['counts']} |")
md += ['','## Every annotated interval','',
       '| Examinee | Time | Annotation | Samples | JSON categories | Estimate range | Exact agreement |','|---|---|---|---:|---|---|---|']
for r in rows:
    pct = 'Unsupported' if r['label']=='down' else f"{r['exact_match_pct']:.1f}%" if r['samples'] else 'No samples'
    md.append(f"| {r['participant']} | {r['interval']} | {r['label']} | {r['samples']} | {r['counts']} | {r['min_angle']} to {r['max_angle']} | {pct} |")
md += ['','## Annotation issues','', 'Obvious spelling errors were normalized. Timestamp endpoints were used when the written duration disagreed.']
for issue in issues: md.append('- '+str(issue))
md += ['','## Interpretation limits','',
    '- Center measures horizontal position only, so it does not rule out looking down.',
    '- The annotations contain center, left, right, and down; no explicit offscreen labels. They cannot establish the correct offscreen threshold.',
    '- Agreement with center alone does not validate the center threshold: the ability to distinguish sideways observations must also be checked.',
    '- This compares annotations with existing JSON, without independently watching the source videos or verifying synchronization.',
    '- No extractor parameters or existing outputs were changed.']
(OUT/'comparison.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
print(json.dumps({'summaries':summaries,'totals':totals,'issues':issues,'sideways_intervals':[r for r in rows if r['label'] in ['left','right']]},indent=2))
